<?php

namespace App\Models;

use App\Core\Database;

class User
{
    protected $table = 'users';

    public function create(array $data)
    {
        $db = new Database;
        $db->insert($this->table, $data);
    }
}