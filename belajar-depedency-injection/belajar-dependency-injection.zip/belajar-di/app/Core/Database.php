<?php

namespace App\Core;

class Database
{
    public function insert(string $table, array $data)
    {
        echo 'insert '.json_encode($data).' to '. $table .' table';
    }

    public function update(string $table, int $id, array $data)
	{
		echo 'update '.json_encode($data).' to '. $table .' table where id=' . $id;
	}
}
